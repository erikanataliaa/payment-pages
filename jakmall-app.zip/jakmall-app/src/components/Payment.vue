<template>
  <v-container fill-height fluid style="background-color: #fff2ccff">
    <!-- <v-row align="center" justify="center"> -->
    <v-layout align-center justify-center>
      <v-stepper
        v-model="e1"
        style="width: 80%"
        height="95vh"
        class="elevation-0"
      >
        <v-row justify="center">
          <v-stepper-header
            style="
              width: 50%;
              height: 50px;
              border-radius: 50px;
              background: #fff2ccff;
            "
            class="elevation-0"
          >
            <v-container class="pa-0 ma-1">
              <v-row>
                <v-stepper-step :complete="e1 > 1" step="1" color="#FF8A00">
                  Delivery
                </v-stepper-step>

                <v-divider></v-divider>

                <v-stepper-step :complete="e1 > 2" step="2" color="#FF8A00">
                  Payment
                </v-stepper-step>

                <v-divider></v-divider>

                <v-stepper-step step="3" color="#FF8A00">
                  Finish
                </v-stepper-step>
              </v-row>
            </v-container>
          </v-stepper-header>
        </v-row>

        <v-stepper-items>
          <v-stepper-content step="1" class="pa-4">
            <v-row class="ma-1">
              <v-icon> mdi-arrow-left </v-icon>
              Back to cart
            </v-row>
            <v-layout row wrap>
              <v-flex md9 class="lg5-custom pa-4">
                <v-container>
                  <section class="g-padding-B">
                    <div class="d-flex flex-row">
                      <h1 style="color: #ff8a00">Delivery Details</h1>
                      <v-spacer />
                      <v-checkbox
                        label="Send as dropshipper"
                        v-model="sendAsDropshipper"
                        color="#FF8A00"
                      >
                      </v-checkbox>
                    </div>
                    <v-form v-model="isFormValid">
                      <div class="d-flex flex-row">
                        <v-text-field
                          required
                          v-model="e_Mail"
                          :rules="emailRules"
                          outlined
                          placeholder="Email"
                          style="width: 50%"
                          color="green"
                          :append-icon="emailValid ? mdi - check : ''"
                        ></v-text-field>

                        <v-spacer />
                        <v-text-field
                          required
                          color="green"
                          v-model="dropshipperName"
                          placeholder="Dropshipper name"
                          :disabled="!sendAsDropshipper"
                          outlined
                          style="width: 40%"
                        >
                        </v-text-field>
                      </div>

                      <div class="d-flex flex-row">
                        <v-text-field
                          required
                          color="green"
                          placeholder="Phone Number"
                          :rules="[
                            rules.required,
                            rules.counter,
                            rules.phoneNumberRules,
                          ]"
                          outlined
                          style="width: 50%"
                          v-model="phoneNumber"
                        >
                        </v-text-field>

                        <v-spacer />
                        <v-text-field
                          required
                          color="green"
                          placeholder="Dropshipper phone number"
                          :rules="[rules.counter, rules.phoneNumberRules]"
                          :disabled="!sendAsDropshipper"
                          outlined
                          style="width: 40%"
                        >
                        </v-text-field>
                      </div>

                      <div>
                        <v-text-field
                          color="green"
                          counter="120"
                          placeholder="Delivery Address"
                          :rules="[rules.required, rules.addressCounter]"
                          outlined
                          v-model="address"
                          height="20vh"
                          style="width: 53%"
                        >
                        </v-text-field>
                      </div>
                    </v-form>
                  </section>
                </v-container>
              </v-flex>
              <v-divider vertical></v-divider>
              <v-flex md3 class="lg5-custom pl-5 pr-5 pb-5 pt-0">
                <div>
                  <v-column>
                    <h2 style="color: #ff8a00">Summary</h2>

                    <p style="color: grey">10 items purchased</p>

                    <v-container style="height: 150px" />

                    <v-container class="pa-3">
                      <v-row>
                        <p style="color: grey">Cost of goods</p>
                        <v-spacer />
                        <p class="font-weight-bold">500,000</p>
                      </v-row>
                      <v-row>
                        <p style="color: grey">Dropshipping fee</p>
                        <v-spacer />
                        <p class="font-weight-bold">
                          {{
                            sendAsDropshipper
                              ? (5900).toLocaleString("en-US")
                              : (this.dropshippingFee = 0)
                          }}
                        </p>
                      </v-row>

                      <v-row>
                        <h2 style="color: #ff8a00">Total</h2>
                        <v-spacer />

                        <h2 style="color: #ff8a00">
                          {{
                            sendAsDropshipper
                              ? (this.cost + 5900).toLocaleString("en-US")
                              : this.cost.toLocaleString("en-US")
                          }}
                        </h2>
                      </v-row>
                    </v-container>
                    <v-row justify="center">
                      <v-btn
                        color="#FF8A00"
                        class="white--text mt-8 no-uppercase"
                        @click="e1 = 2"
                        :disabled="!isFormValid"
                        width="100%"
                        height="50px"
                        >Continue to Payment</v-btn
                      >
                    </v-row>
                  </v-column>
                </div>
              </v-flex>
            </v-layout>
          </v-stepper-content>

          <v-stepper-content step="2">
            <v-row class="ma-1" @click="e1 = 1">
              <v-icon> mdi-arrow-left </v-icon>
              Back to delivery
            </v-row>
            <v-layout row wrap>
              <v-flex md9 class="lg5-custom pa-4">
                <v-container>
                  <section class="g-padding-B">
                    <div class="d-flex flex-row mb-5">
                      <h1 style="color: #ff8a00">Shipment</h1>
                    </div>

                    <v-btn-toggle
                      v-model="shipment"
                      tile
                      color="green"
                      group
                      flat
                    >
                      <v-btn
                        value="GO-SEND"
                        outlined
                        style="width: 200px"
                        height="70px"
                        class="pa-3 align-center no-uppercase"
                      >
                        <v-row class="pa-5">
                          <v-column class="pt-3">
                            <p>GO-SEND<br />15,000</p>
                          </v-column>
                          <v-spacer />
                          <v-icon v-if="shipment == 'GO-SEND'" color="green"
                            >mdi-check</v-icon
                          >
                        </v-row>
                      </v-btn>

                      <v-btn
                        value="JNE"
                        outlined
                        style="width: 200px"
                        height="70px"
                        class="pa-3 no-uppercase"
                      >
                        <v-row class="pa-5">
                          <v-column class="pt-3">
                            <p>JNE<br />9,000</p>
                          </v-column>
                          <v-spacer />
                          <v-icon v-if="shipment == 'JNE'" color="green"
                            >mdi-check</v-icon
                          >
                        </v-row>
                      </v-btn>

                      <v-btn
                        value="Personal Courier"
                        outlined
                        style="width: 200px"
                        height="70px"
                        class="pa-3 no-uppercase"
                      >
                        <v-row class="pa-5">
                          <v-column class="pt-3">
                            <p>Personal Courier<br />15,000</p>
                          </v-column>
                          <v-spacer />
                          <v-icon
                            v-if="shipment == 'Personal Courier'"
                            color="green"
                            >mdi-check</v-icon
                          >
                        </v-row>
                      </v-btn>
                    </v-btn-toggle>
                  </section>

                  <section class="g-padding-B">
                    <div class="d-flex flex-row mb-5 mt-5">
                      <h1 style="color: #ff8a00">Payment</h1>
                    </div>

                    <v-btn-toggle
                      v-model="payment"
                      tile
                      color="green"
                      group
                      @click="paymentMethod()"
                    >
                      <v-btn
                        value="e-Wallet"
                        outlined
                        style="width: 200px"
                        height="70px"
                        class="pa-3 no-uppercase"
                      >
                        <v-row class="pa-5" align="center">
                          <v-column class="pt-3">
                            <p>E-Wallet<br />1,500,000 left</p>
                            <!-- <p>1,500,000 left</p> -->
                          </v-column>
                          <v-spacer />
                          <v-icon v-if="payment == 'e-Wallet'" color="green"
                            >mdi-check</v-icon
                          >
                        </v-row>
                      </v-btn>

                      <v-btn
                        value="Bank Transfer"
                        outlined
                        style="width: 200px"
                        height="70px"
                        class="pa-3 no-uppercase"
                      >
                        <v-row class="pa-5" align="center">
                          <p class="pt-3">Bank Transfer</p>
                          <v-spacer />
                          <v-icon
                            v-if="payment == 'Bank Transfer'"
                            color="green"
                            >mdi-check</v-icon
                          >
                        </v-row>
                      </v-btn>

                      <v-btn
                        value="Virtual Account"
                        outlined
                        style="width: 200px"
                        height="70px"
                        class="pa-3 no-uppercase"
                      >
                        <v-row class="pa-5" align="center">
                          <p class="pt-3">Virtual Account</p>
                          <v-spacer />
                          <v-icon
                            v-if="payment == 'Virtual Account'"
                            color="green"
                            >mdi-check</v-icon
                          >
                        </v-row>
                      </v-btn>
                    </v-btn-toggle>
                  </section>
                </v-container>
              </v-flex>
              <v-divider vertical></v-divider>
              <v-flex md3 class="lg5-custom pl-5 pr-5 pb-5 pt-0">
                <div>
                  <v-column>
                    <h2 style="color: #ff8a00">Summary</h2>

                    <p style="color: grey">10 items purchased</p>

                    <p>Delivery Estimation</p>
                    <div v-if="this.shipment == 'GO-SEND'">
                      <p style="color: green">Today by {{ this.shipment }}</p>
                    </div>

                    <div v-if="this.shipment == 'JNE'">
                      <p style="color: green">2 Days by {{ this.shipment }}</p>
                    </div>

                    <div v-if="this.shipment == 'Personal Courier'">
                      <p style="color: green">1 Day by {{ this.shipment }}</p>
                    </div>

                    <v-container style="height: 20px" />

                    <v-container class="pa-3">
                      <v-row>
                        <p style="color: grey">Cost of goods</p>
                        <v-spacer />
                        <p class="font-weight-bold">500,000</p>
                      </v-row>
                      <v-row>
                        <p style="color: grey">Dropshipping fee</p>
                        <v-spacer />
                        <p class="font-weight-bold">
                          {{
                            sendAsDropshipper
                              ? (5900).toLocaleString("en-US")
                              : (this.dropshippingFee = 0)
                          }}
                        </p>
                      </v-row>

                      <v-row>
                        <div v-if="this.shipment.length != 0">
                          <p style="color: gray">
                            {{ this.shipment + " shipment" }}
                          </p>
                        </div>
                        <v-spacer />
                        <div v-if="this.shipment == 'GO-SEND'">
                          <p class="font-weight-bold">15,000</p>
                        </div>
                        <div v-if="this.shipment == 'Personal Courier'">
                          <p class="font-weight-bold">29,000</p>
                        </div>
                        <div v-if="this.shipment == 'JNE'">
                          <p class="font-weight-bold">9,000</p>
                        </div>
                      </v-row>

                      <v-row>
                        <h2 style="color: #ff8a00">Total</h2>
                        <v-spacer />

                        <h2 style="color: #ff8a00">
                          {{
                            sendAsDropshipper
                              ? (this.cost + 5900).toLocaleString("en-US")
                              : this.cost.toLocaleString("en-US")
                          }}
                        </h2>
                      </v-row>

                      <v-row justify="center">
                        <v-btn
                          color="#FF8A00"
                          class="white--text pa-2 mt-3 no-uppercase"
                          @click="e1 = 3"
                          width="100%"
                          height="50px"
                          :disabled="
                            this.shipment.length == 0 ||
                            this.payment.length == 0
                          "
                          >Pay with e-wallet</v-btn
                        >
                      </v-row>
                    </v-container>
                  </v-column>
                </div>
              </v-flex>
            </v-layout>
          </v-stepper-content>

          <v-stepper-content step="3">
            <v-row class="ma-1" @click="e1 = 2">
              <v-icon> mdi-arrow-left </v-icon>
              Back to Payment
            </v-row>
            <v-layout row wrap>
              <v-flex md9 class="lg5-custom pa-4">
                <v-container fill-height fluid>
                  <v-row align="center" justify="center">
                    <section class="g-padding-B">
                      <div class="d-flex flex-row mb-5">
                        <h1 style="color: #ff8a00">Thank you</h1>
                      </div>

                      <p>Order ID : {{ generateOrderId(5) }}</p>
                      <p style="color: grey"></p>

                      <div v-if="this.shipment == 'GO-SEND'">
                        <p style="color: grey">
                          Your order will be delivered Today by
                          {{ this.shipment }}
                        </p>
                      </div>

                      <div v-if="this.shipment == 'JNE'">
                        <p style="color: grey">
                          Your order will be delivered 2 Days by
                          {{ this.shipment }}
                        </p>
                      </div>

                      <div v-if="this.shipment == 'Personal Courier'">
                        <p style="color: grey">
                          Your order will be delivered 1 Day by
                          {{ this.shipment }}
                        </p>
                      </div>

                      <v-container style="height: 70px" />

                      <v-row class="ma-1" @click="e1 = 1">
                        <v-icon> mdi-arrow-left </v-icon>
                        Go to homepage
                      </v-row>
                    </section>
                  </v-row>
                </v-container>
              </v-flex>
              <v-divider vertical></v-divider>
              <v-flex md3 class="lg5-custom pl-5 pr-5 pb-5 pt-0">
                <div>
                  <v-column>
                    <h2 style="color: #ff8a00">Summary</h2>

                    <p style="color: grey">10 items purchased</p>

                    <p>Delivery Estimation</p>
                    <div v-if="this.shipment == 'GO-SEND'">
                      <p style="color: green">Today by {{ this.shipment }}</p>
                    </div>

                    <div v-if="this.shipment == 'JNE'">
                      <p style="color: green">2 Days by {{ this.shipment }}</p>
                    </div>

                    <div v-if="this.shipment == 'Personal Courier'">
                      <p style="color: green">1 Day by {{ this.shipment }}</p>
                    </div>

                    <v-divider class="mb-1"></v-divider>

                    <p>Payment Method</p>
                    <p style="color: green">{{ this.payment }}</p>

                    <!-- <v-container style="height: 5px" /> -->

                    <v-container class="pa-3">
                      <v-row>
                        <p style="color: grey">Cost of goods</p>
                        <v-spacer />
                        <p class="font-weight-bold">500,000</p>
                      </v-row>
                      <v-row>
                        <p style="color: grey">Dropshipping fee</p>
                        <v-spacer />
                        <p class="font-weight-bold">
                          {{
                            sendAsDropshipper
                              ? (5900).toLocaleString("en-US")
                              : (this.dropshippingFee = 0)
                          }}
                        </p>
                      </v-row>

                      <v-row>
                        <div v-if="this.shipment == 'GO-SEND'">
                          <p style="color: gray">
                            {{ this.shipment }} shipment
                          </p>
                        </div>
                        <div v-if="this.shipment == 'Personal Courier'">
                          <p style="color: gray">
                            {{ this.shipment }} shipment
                          </p>
                        </div>
                        <div v-if="this.shipment == 'JNE'">
                          <p style="color: gray">
                            {{ this.shipment }} shipment
                          </p>
                        </div>
                        <v-spacer />
                        <div v-if="this.shipment == 'GO-SEND'">
                          <p class="font-weight-bold">50,000</p>
                        </div>
                        <div v-if="this.shipment == 'Personal Courier'">
                          <p class="font-weight-bold">25,000</p>
                        </div>
                        <div v-if="this.shipment == 'JNE'">
                          <p class="font-weight-bold">10,000</p>
                        </div>
                      </v-row>

                      <v-row>
                        <h2 style="color: #ff8a00">Total</h2>
                        <v-spacer />

                        <h2 style="color: #ff8a00">
                          {{
                            sendAsDropshipper
                              ? (this.cost + 5900).toLocaleString("en-US")
                              : this.cost
                          }}
                        </h2>
                      </v-row>
                    </v-container>
                  </v-column>
                </div>
              </v-flex>
            </v-layout>
          </v-stepper-content>
        </v-stepper-items>
      </v-stepper>
    </v-layout>
    <!-- </v-row> -->
  </v-container>
</template>

<script>
export default {
  name: "HelloWorld",

  data() {
    return {
      e1: 1,
      emailValid: false,
      orderId: "",
      e_Mail: "",
      emailRules: [],
      dropshipperName: "",
      dropshipperNameRules: [],
      sendAsDropshipper: false,
      dropshippingFee: 5900,
      cost: 500000,
      total: 0,
      phoneNumber: "",
      address: "",
      shipment: "",
      payment: "",
      onClick: false,
      deliveryEstimation: "",
      rules: {
        required: (value) => !!value || "Required.",
        counter: (value) => (value.length >= 6 && value.length <= 20) || "",
        phoneNumberRules: (value) => {
          if (!value.trim()) return true;
          if (/^[0-9]+$/.test(value)) return true;
          return "";
        },
        addressCounter: (value) => value.length <= 120 || "",
      },
    };
  },
  watch: {
    e_Mail: function (mail) {
      if (mail !== "") {
        this.emailRules = [
          (v) =>
            v.match(
              /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            ) || "",
        ];
      } else if (mail === "") {
        this.emailRules = [];
      }
    },
  },

  methods: {
    onSubmit() {
      if (this.$refs.form.validate()) {
        this.isClick = true;
      }
    },

    generateOrderId(length) {
      var result = [];
      var characters =
        "ABCDEFGHIJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
      var charactersLength = characters.length;
      for (var i = 0; i < length; i++) {
        result.push(
          characters.charAt(Math.floor(Math.random() * charactersLength))
        );
      }
      return result.join("");
    },
  },

  computed: {
    emailAppendIcon() {
      return !(this.e_Mail.length != 0) && "mdi-check";
    },
  },
};
</script>

<style>
.no-uppercase {
  text-transform: unset !important;
}
</style>

