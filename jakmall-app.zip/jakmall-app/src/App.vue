<template>
  <v-app>
    <v-main>
      <Payment />
    </v-main>
  </v-app>
</template>

<script>
import Payment from "./components/Payment";

export default {
  name: "App",

  components: {
    Payment,
  },

  data: () => ({
    //
  }),
};
</script>
